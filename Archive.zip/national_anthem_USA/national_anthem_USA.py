#!/usr/bin/env python3
import pyttsx3_say
import os
folder=os.path.dirname(__file__)
txt="national_anthem_USA.txt"
path=folder+"/"+txt
myfile=[x.rstrip() for x in open(path,'r').readlines()]
for line in myfile:
	print(line)
	pyttsx3_say.say(line)