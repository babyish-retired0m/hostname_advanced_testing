#!/usr/bin/env python3
import pyttsx3_say_copy
import os
folder=os.path.dirname(__file__)
txt="national_anthem_USA_copy.txt"
path=folder+"/"+txt
myfile=[x.rstrip() for x in open(path,'r').readlines()]
for line in myfile:
	print(line)
	pyttsx3_say_copy.say(line)