#!/usr/bin/env python3
"""try:
	import pyttsx3
except ImportError:
    raise SystemExit("Please install pyttsx3, pip3 install pyttsx3")"""
import os
def say(txt):
	#pyttsx3.speak(txt)
	os.system('say ' + txt)
if __name__ == '__main__':
	text="I will speak this text"
	say(text)