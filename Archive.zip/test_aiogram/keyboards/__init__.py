from keyboards.client_kb import kb_client
from keyboards import admin_kb